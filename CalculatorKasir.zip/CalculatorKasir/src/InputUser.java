import javax.swing.JOptionPane;

public class InputUser {
    private String nama;
    private String menu;
    private int jumlah;
    public double harga;

    public void inputDataGUI() {
        this.nama = JOptionPane.showInputDialog("Masukkan Nama Pelanggan:");
        this.menu = JOptionPane.showInputDialog("Masukkan Menu:");
        String inputJumlah = JOptionPane.showInputDialog("Masukkan Jumlah Pesanan:");
        this.jumlah = Integer.parseInt(inputJumlah);
        String inputHarga = JOptionPane.showInputDialog("Masukkan Harga per item:");
        this.harga = Double.parseDouble(inputHarga);
    }

    public String getNama() {
        return nama;
    }

    public String getMenu() {
        return menu;
    }

    public int getJumlah() {
        return jumlah;
    }

    public double getHarga() {
        return harga;
    }
}
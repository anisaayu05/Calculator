public class Calculator {
    double findTotal(double harga, int jumlah, double pajak, double tip) {
        return (harga * jumlah * (1 + pajak + tip));
    }

    double findTax(double harga, double pajak) {
        return(harga*(1+pajak));
    }

    double findTip(double harga, double tip) {
        return(harga*(1+tip));
    }
}
import javax.swing.*;

public class OutputUser {
    private InputUser input;

    public OutputUser(InputUser input) {
        this.input = input;
    }

    public void output(double hargaTotal, double totalPajak, double totalTip) {
        String output = "Nama Pelanggan: " + input.getNama() + "\n"
                + "Menu: " + input.getMenu() + "\n"
                + "Jumlah Pesanan: " + input.getJumlah() + "\n"
                + "Harga per item: " + input.getHarga() + "\n"
                + "Pajak: " + totalPajak + "\n"
                + "Tip: " + totalTip + "\n"
                + "Total Harga: " + hargaTotal;

        JOptionPane.showMessageDialog(null, output);
    }
}
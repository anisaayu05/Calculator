public class CafeInDriver {
    public static void main(String[] args) {
        double pajak = 0.05;
        double tip = 0.15;

        InputUser input = new InputUser();
        Calculator calc = new Calculator();
        OutputUser output = new OutputUser(input);

        input.inputDataGUI();

        double hargaTotal = calc.findTotal(input.getHarga(), input.getJumlah(), pajak, tip);
        double totalPajak = calc.findTax(input.getHarga(), pajak);
        double totalTip = calc.findTip(input.getHarga(), tip);

        output.output(hargaTotal, totalPajak, totalTip);
    }
}